#!/usr/bin/python
from operator import sub
from operator import add

### Program to read self-shielded microscopic XS from DRAGON ASCII output and create material files for OpenMOC ###########################
# AUTHOR: Augusto Hernandez-Solis, October 2014 @ KTH, Sweden

###########################################################################################################################################
# WARNING: THIS PROGRAM IS CAPABLE OF PRODUCING TWO TYPES OF MATERIAL FILES: ONE CONSIDERING ISOTROPIC SCATTERING, AND THE OTHER ONE      #
# CONSIDERING THE FOLLOWING TRANSPORT CORRECTION: NTOT_TRANC = NTOT0 - SIGS01 and SCAT_MTX_TRANC = SCAT00 - SCAT01                        #
# THIS MEANS THAT TO EACH TERM OF THE P0 SCATTERING MATRIX IS SUBSTRACTED EACH TERM OF THE P1 SCATTERING MATRIX.                          #
# THIS IS DONE LIKE THIS IN ORDER TO COMPLY WITH THE n_tot MATRIX VERIFICATION DONE BY OpenMOC. HOWEVER, THIS TYPE OF TRANSPORT CORECTION #
# NEEDS TO BE VERIFIED AND DOES NOT MEAN IS ENTIRELY TRUE. THEREFORE, DIFFERENT TYPES OF CORRECTION COULD APPLY. YOU CAN MODIFY SUCH      #
# CORRECTION TO OTHER TYPES IF DESIRED, SINCE BOTH P0 AND P1 MATRICES ARE PROVIDED.                                                       #
#################################### !!! YOU HAVE BEEN WARNED !!! #########################################################################

############################# THE ONLY FILE THAT HAS BEEN VERIFIED TO WORK PROPERLY IS THE ISOTROPIC ONE ##################################


### Parameters to be defined by the user ##################################################################################################

### Energy groups as in DRAGON microlib ###
global GROUPS
GROUPS=69

### Variables defined by the user for the different mixtures ###
mixtures=['Moderator','Cladding','Fuel']

### Strings of the mixture number identification tag contained in DRAGON.### 
### E.g. If in the DRAGON input deck the first mixture is defined as MIX 1, here it will be 0001 ###
mix_drag=['0001',     '0002',    '0003']

#################Isotopes as defined exactly in the DRAGON input deck (EACH STRING SHOULD CONTAIN 6 TERMS!!!)###########################
#I like to separate the mixtures in rows#
isotopes=['H1H2O ','O16_1 ','BNat  ',           
          'Zr91  ','O16_2 ','Fe56  ','Cr52  ',
	  'O16_3 ','U235  ','U238  ','Pu238 ','Pu239 ','Pu240 ','Pu241 ','Pu242 ','AM241 ']

#Atomic densities as exactly in the DRAGON input deck (the order of the different elements of this array should match the above array)##
# Atomic densities for the assembly test #

atom_dens=['4.76690E-2','2.38345E-2','2.38103E-5',
           '4.18621E-2','3.06711E-4','1.47624E-4','7.54987E-5',
	   '4.49355E-2','5.39237E-4','1.17285E-2','2.10900E-5','3.57900E-4','2.10800E-4','7.16500E-5','6.55400E-5','1.08300E-5']

# Atomic densities for the pin test #

#atom_dens=['4.76690E-2','2.38345E-2','0.0',
#           '4.18621E-2','3.06711E-4','1.47624E-4','7.54987E-5',
#	   '4.49355E-2','7.39237E-4','2.17285E-2','0.0','0.0','0.0','0.0','0.0','0.0']

################Local variable names for this script (defined by the user and nothing to do with DRAGON syntax)#########################
isot_py=['H1H2O','O_H2O','B_Nat','Zr_91','O_CLD','Fe_56','Cr_52','O_FUE','U_235','U_238','Pu238','Pu239','Pu240','Pu241','Pu242','AM241']

### Isotopes that were self-shielded by DRAGON (i.e. if next to the isotope declaration in the DRAGON input deck there is a one -> ss
### String declaration here has the same syntax as isot_py
ss_isot_py=['U_235','U_238','Pu238','Pu239','Pu240','Pu241','Pu242','AM241']

################Different file names####################################################################################################
# 1-> SS library name produced by DRAGON and to be read by this script
# 2-> Material_tranc.py file name to be produced by this script for the transport corrected case
# 3-> Material_isot.py file name to be produced by this script for the isotropic case
# 4-> XS.m Matlab/Octave file name that contains the different XS for future Matlab post-processing 

#files=['library_ss_pin_69g','test_tranc_mat_pin_69.py','test_isot_mat_pin_69.py','XS_69_pin.m']

files=['library_ss_assmb_69g_MOC','test_tranc_mat_assmb_69_MOC.py','test_isot_mat_assmb_69_MOC.py','XS_69_assmb_MOC.m']

###########################################################################################################################################
##############################################################################################
### THIS ARRAY MATCHES THE DIFFERENT REACTION NAMES (IN DRAGON FORMAT) THAT ARE CONTAINED IN #
### THE SELF-SHIELDED XS LIBRARY PRODUCED BY DRAGON. IF OTHER REACTION IS WANTED TO BE ADDED,#
### IT SHOULD MATCH THE DRAGON REACTION NAME SYNTAX ##########################################
reactions=['NTOT0                                                                           ',
           'SIGS00                                                                          ',
           'SIGS01                                                                          ',
           'SCAT00                                                                          ',
           'NJJS00                                                                          ',
           'IJJS00                                                                          ',
           'SCAT01                                                                          ',
           'NJJS01                                                                          ',
           'IJJS01                                                                          ',
           'CHI                                                                             ',
           'NUSIGF                                                                          ',
           'NFTOT                                                                           ',
           'NG                                                                              ' ]
	   
reac_py=['NTOT0','SIG00','SIG01','SCAT0','NJS00','IJS00','SCAT1','NJS01','IJS01','CHI_X',
'NUSIF','NFTOT','N_GAM']
###############################################################################################

isot=0
while isot < len(isotopes):
 print "Reading current isotope:%s"%isot_py[isot]
 reac=0
 
 while reac < len(reactions):
  flag=0
  exec("f=open('%s','r')"%files[0]) 
  while True:
   a=f.readline()
 
   if len(a)==0:
    break
   if a[0:6]==isotopes[isot]:
    mix_aux=a[8:12]
    a=f.readline()
    a=f.readline()
    if a[0:3]=='AWR':
     while a[0:10]!='->      -2':
      a=f.readline()
      if a[0:80]==reactions[reac]:
       flag=1
       a=f.readline()
       exec("vec_%s_%s_%s=[]"%(isot_py[isot],reac_py[reac],mix_aux))
       while a[0]!='-':
        
        b=a.split()
        c= [float(d) for d in b] 
        
        for i in range(len(c)):
         
         exec("vec_%s_%s_%s.append(c[i])"%(isot_py[isot],reac_py[reac],mix_aux))
        
        a=f.readline()
       #
      #
     #
    #
   #There is no certain reaction for a certain isotope -> Initialize vectors to zero
  if flag==0:
   
   exec("vec_%s_%s_%s=[0]*GROUPS"%(isot_py[isot],reac_py[reac],mix_aux))

  f.close()
  reac=reac+1
  
  ###### CALCULATION OF THE SCATTERING MATRICES COLUMNS S0, S1, SCAT_TRANC ############################################
  # THIS CALCULATION IS BASED ON THE ALGORITHM THAT DRAGON HAS IMPLEMENTED TO ONLY PRINT NON-ZERO VALUES IN CASE THERE#
  # IS NO UP-SCATTERING. THIS IS THE REASON WHY WE NEED TO READ THE MATRICES NJJS00, IJJS00, NJJS01 AND IJJS01 FROM   #
  # THE SS LIBRARY GIVEN BY DRAGON. FOR MORE INFO ABOUT THIS ALGORITHM, CHECK THE DRAGON USER MANUAL                  #
  #####################################################################################################################
  
  if reac==len(reactions):
   diff_aux0=[]
   diff_aux1=[]
   for g in range(GROUPS):
   
    exec("col_%s_%s_SCAT0_MTX_%s=[0]*GROUPS"%(g,isot_py[isot],mix_aux))
    exec("col_%s_%s_SCAT1_MTX_%s=[0]*GROUPS"%(g,isot_py[isot],mix_aux))
    exec("diff_aux0=map(sub,vec_%s_IJS00_%s,vec_%s_NJS00_%s)"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux))
    exec("diff_aux1=map(sub,vec_%s_IJS01_%s,vec_%s_NJS01_%s)"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux))

    if g==0:

     from_NJS00=0
     exec("to_NJS00=vec_%s_NJS00_%s[g]"%(isot_py[isot],mix_aux))
     
     from_NJS01=0
     exec("to_NJS01=vec_%s_NJS01_%s[g]"%(isot_py[isot],mix_aux))
     col_aux01=[]
     col_aux11=[]
     exec("col_aux01=vec_%s_SCAT0_%s[from_NJS00:int(to_NJS00)]"%(isot_py[isot],mix_aux))
     exec("col_aux11=vec_%s_SCAT1_%s[from_NJS01:int(to_NJS01)]"%(isot_py[isot],mix_aux))
     col_aux02=[0]*len(col_aux01)
     count=0
     end=len(col_aux01)
     while count < len(col_aux01):
      col_aux02[count] = col_aux01[end-1]
      count=count+1
      end=end-1
          
     col_aux12=[0]*len(col_aux11)
     count=0
     end=len(col_aux11)
     while count < len(col_aux11):
      col_aux12[count] = col_aux11[end-1]
      count=count+1
      end=end-1
      
     ################### P0 and P1 SCATTERING MATRICES COULMNS COMPUTATION ############################################
     count=0
     while count < len(col_aux02):
      exec("col_%s_%s_SCAT0_MTX_%s[int(diff_aux0[g])+count]=col_aux02[count]"%(g,isot_py[isot],mix_aux))
      count=count+1

     count=0
     while count < len(col_aux12):
      exec("col_%s_%s_SCAT1_MTX_%s[int(diff_aux1[g])+count]=col_aux12[count]"%(g,isot_py[isot],mix_aux))
      count=count+1
      
     ###### TRANSPORT-CORRECTION IN THE COLUMNS OF THE MICROSCOPIC SCATTERING MATRIX (i.e. SCAT_MTX = SCAT0 - SCAT1 (MAYBE THIS IS NOT ENTIRELY CORRECT!!!########
     exec("col_%s_%s_mic_SCAT_TRANC_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mic_SCAT_TRANC_MTX_%s=map(sub,col_%s_%s_SCAT0_MTX_%s,col_%s_%s_SCAT1_MTX_%s)"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))
     
     #MACROSCOPIC SCATTERING MATRIX (TRANSPORT-CORRECTED) AND P1 MATRIX COLUMNS COMPUTATION #####
     exec("col_%s_%s_mac_SCAT_TRANC_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_TRANC_MTX_%s=[float(atom_dens[isot])*col_%s_%s_mic_SCAT_TRANC_MTX_%s[i] for i in range(len(col_%s_%s_mic_SCAT_TRANC_MTX_%s))]"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_P1_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_P1_MTX_%s=[float(atom_dens[isot])*col_%s_%s_SCAT1_MTX_%s[i] for i in range(len(col_%s_%s_SCAT1_MTX_%s))]"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))


     #MACROSCOPIC SCATTERING MATRIX (ISOTROPIC) COLUMNS COMPUTATION #####
     exec("col_%s_%s_mic_SCAT_ISOT_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mic_SCAT_ISOT_MTX_%s=col_%s_%s_SCAT0_MTX_%s"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_ISOT_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_ISOT_MTX_%s=[float(atom_dens[isot])*col_%s_%s_mic_SCAT_ISOT_MTX_%s[i] for i in range(len(col_%s_%s_mic_SCAT_ISOT_MTX_%s))]"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))
          
    elif g==1:
    

     exec("from_NJS00=vec_%s_NJS00_%s[g-1]"%(isot_py[isot],mix_aux))
     exec("to_NJS00=vec_%s_NJS00_%s[g]+vec_%s_NJS00_%s[g-1]"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux))
     exec("sum_aux0=vec_%s_NJS00_%s[g-1]"%(isot_py[isot],mix_aux)) 
      
     exec("from_NJS01=vec_%s_NJS01_%s[g-1]"%(isot_py[isot],mix_aux))
     exec("to_NJS01=vec_%s_NJS01_%s[g]+vec_%s_NJS01_%s[g-1]"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux))
     exec("sum_aux1=vec_%s_NJS01_%s[g-1]"%(isot_py[isot],mix_aux))

     col_aux01=[]
     col_aux11=[]
     exec("col_aux01=vec_%s_SCAT0_%s[int(from_NJS00):int(to_NJS00)]"%(isot_py[isot],mix_aux))
     exec("col_aux11=vec_%s_SCAT1_%s[int(from_NJS01):int(to_NJS01)]"%(isot_py[isot],mix_aux))
     col_aux02=[0]*len(col_aux01)
     col_aux12=[0]*len(col_aux11)

     count=0
     end=len(col_aux01)
     while count < len(col_aux01):
      col_aux02[count] = col_aux01[end-1]
      count=count+1
      end=end-1

     count=0
     end=len(col_aux11)
     while count < len(col_aux11):
      col_aux12[count] = col_aux11[end-1]
      count=count+1
      end=end-1
      
     ################### P0 and P1 SCATTERING MATRICES COULMNS COMPUTATION ############################################
     count=0
     while count < len(col_aux02):
      exec("col_%s_%s_SCAT0_MTX_%s[int(diff_aux0[g])+count]=col_aux02[count]"%(g,isot_py[isot],mix_aux))
      count=count+1

     count=0
     while count < len(col_aux12):
      exec("col_%s_%s_SCAT1_MTX_%s[int(diff_aux1[g])+count]=col_aux12[count]"%(g,isot_py[isot],mix_aux))
      count=count+1
      
     ###### TRANSPORT-CORRECTION IN THE COLUMNS OF THE MICROSCOPIC SCATTERING MATRIX (i.e. SCAT_MTX = SCAT0 - SCAT1 (MAYBE THIS IS NOT ENTIRELY CORRECT!!!########
     exec("col_%s_%s_mic_SCAT_TRANC_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mic_SCAT_TRANC_MTX_%s=map(sub,col_%s_%s_SCAT0_MTX_%s,col_%s_%s_SCAT1_MTX_%s)"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))
     
     #MACROSCOPIC SCATTERING MATRIX (TRANSPORT-CORRECTED) AND P1 MATRIX COLUMNS COMPUTATION #####
     exec("col_%s_%s_mac_SCAT_TRANC_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_TRANC_MTX_%s=[float(atom_dens[isot])*col_%s_%s_mic_SCAT_TRANC_MTX_%s[i] for i in range(len(col_%s_%s_mic_SCAT_TRANC_MTX_%s))]"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_P1_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_P1_MTX_%s=[float(atom_dens[isot])*col_%s_%s_SCAT1_MTX_%s[i] for i in range(len(col_%s_%s_SCAT1_MTX_%s))]"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))

     #MACROSCOPIC SCATTERING MATRIX (ISOTROPIC) COLUMNS COMPUTATION #####
     exec("col_%s_%s_mic_SCAT_ISOT_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mic_SCAT_ISOT_MTX_%s=col_%s_%s_SCAT0_MTX_%s"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_ISOT_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_ISOT_MTX_%s=[float(atom_dens[isot])*col_%s_%s_mic_SCAT_ISOT_MTX_%s[i] for i in range(len(col_%s_%s_mic_SCAT_ISOT_MTX_%s))]"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))
      
    else:

     exec("sum_aux0=sum_aux0+vec_%s_NJS00_%s[g-1]"%(isot_py[isot],mix_aux))
     from_NJS00=sum_aux0
     exec("to_NJS00=from_NJS00+vec_%s_NJS00_%s[g]"%(isot_py[isot],mix_aux))

     exec("sum_aux1=sum_aux1+vec_%s_NJS01_%s[g-1]"%(isot_py[isot],mix_aux))
     from_NJS01=sum_aux1
     exec("to_NJS01=from_NJS01+vec_%s_NJS01_%s[g]"%(isot_py[isot],mix_aux))

     col_aux01=[]
     col_aux11=[]
     exec("col_aux01=vec_%s_SCAT0_%s[int(from_NJS00):int(to_NJS00)]"%(isot_py[isot],mix_aux))
     exec("col_aux11=vec_%s_SCAT1_%s[int(from_NJS01):int(to_NJS01)]"%(isot_py[isot],mix_aux))

     col_aux02=[0]*len(col_aux01)
     count=0
     end=len(col_aux01)
     while count < len(col_aux01):
      col_aux02[count] = col_aux01[end-1]
      count=count+1
      end=end-1

     col_aux12=[0]*len(col_aux11)
     count=0
     end=len(col_aux11)
     while count < len(col_aux11):
      col_aux12[count] = col_aux11[end-1]
      count=count+1
      end=end-1
      
     ################### P0 and P1 SCATTERING MATRICES COULMNS COMPUTATION ############################################
     count=0
     while count < len(col_aux02):
      exec("col_%s_%s_SCAT0_MTX_%s[int(diff_aux0[g])+count]=col_aux02[count]"%(g,isot_py[isot],mix_aux))
      count=count+1

     count=0
     while count < len(col_aux12):
      exec("col_%s_%s_SCAT1_MTX_%s[int(diff_aux1[g])+count]=col_aux12[count]"%(g,isot_py[isot],mix_aux))
      count=count+1
      
     ###### TRANSPORT-CORRECTION IN THE COLUMNS OF THE MICROSCOPIC SCATTERING MATRIX (i.e. SCAT_MTX = SCAT0 - SCAT1 (MAYBE THIS IS NOT ENTIRELY CORRECT!!!########
     exec("col_%s_%s_mic_SCAT_TRANC_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mic_SCAT_TRANC_MTX_%s=map(sub,col_%s_%s_SCAT0_MTX_%s,col_%s_%s_SCAT1_MTX_%s)"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))
     
     #MACROSCOPIC SCATTERING MATRIX (TRANSPORT-CORRECTED) AND P1 MATRIX COLUMNS COMPUTATION #####
     exec("col_%s_%s_mac_SCAT_TRANC_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_TRANC_MTX_%s=[float(atom_dens[isot])*col_%s_%s_mic_SCAT_TRANC_MTX_%s[i] for i in range(len(col_%s_%s_mic_SCAT_TRANC_MTX_%s))]"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_P1_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_P1_MTX_%s=[float(atom_dens[isot])*col_%s_%s_SCAT1_MTX_%s[i] for i in range(len(col_%s_%s_SCAT1_MTX_%s))]"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))

     #MACROSCOPIC SCATTERING MATRIX (ISOTROPIC) COLUMNS COMPUTATION #####
     exec("col_%s_%s_mic_SCAT_ISOT_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mic_SCAT_ISOT_MTX_%s=col_%s_%s_SCAT0_MTX_%s"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_ISOT_MTX_%s=[]"%(g,isot_py[isot],mix_aux))
     exec("col_%s_%s_mac_SCAT_ISOT_MTX_%s=[float(atom_dens[isot])*col_%s_%s_mic_SCAT_ISOT_MTX_%s[i] for i in range(len(col_%s_%s_mic_SCAT_ISOT_MTX_%s))]"%(g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux,g,isot_py[isot],mix_aux))


   ######CALCULATION OF GROUP MACROSCOPIC XS (EXCEPT CHI)##############################################################
   
   exec("n_abs_mic_%s_%s=[]"%(isot_py[isot],mix_aux))
   exec("n_scat_tranc_mic_%s_%s=[]"%(isot_py[isot],mix_aux))
   exec("n_scat_isot_mic_%s_%s=[]"%(isot_py[isot],mix_aux))
   exec("n_tot_isot_mic_%s_%s=[]"%(isot_py[isot],mix_aux))
   exec("n_tot_tranc_mic_%s_%s=[]"%(isot_py[isot],mix_aux))


   exec("n_abs_mic_%s_%s=map(sub,vec_%s_NTOT0_%s,vec_%s_SIG00_%s)"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux,isot_py[isot],mix_aux)) 
   exec("n_scat_tranc_mic_%s_%s=map(sub,vec_%s_SIG00_%s,vec_%s_SIG01_%s)"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux,isot_py[isot],mix_aux))  
   exec("n_scat_isot_mic_%s_%s=vec_%s_SIG00_%s"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux))
   exec("n_tot_isot_mic_%s_%s=vec_%s_NTOT0_%s"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux))  
   exec("n_tot_tranc_mic_%s_%s=map(sub,n_tot_isot_mic_%s_%s,vec_%s_SIG01_%s)"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux,isot_py[isot],mix_aux))


   exec("n_abs_mac_%s_%s=[]"%(isot_py[isot],mix_aux))
   exec("n_scat_tranc_mac_%s_%s=[]"%(isot_py[isot],mix_aux))
   exec("n_scat_isot_mac_%s_%s=[]"%(isot_py[isot],mix_aux))
   exec("n_tot_isot_mac_%s_%s=[]"%(isot_py[isot],mix_aux))
   exec("n_tot_tranc_mac_%s_%s=[]"%(isot_py[isot],mix_aux))
   exec("n_nufis_mac_%s_%s=[]"%(isot_py[isot],mix_aux))
   exec("n_fis_mac_%s_%s=[]"%(isot_py[isot],mix_aux))
   exec("chi_mac_aux_%s_%s=[]"%(isot_py[isot],mix_aux))

   exec("n_abs_mac_%s_%s=[float(atom_dens[isot])*n_abs_mic_%s_%s[i] for i in range(len(n_abs_mic_%s_%s))]"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux,isot_py[isot],mix_aux))
   exec("n_scat_tranc_mac_%s_%s=[float(atom_dens[isot])*n_scat_tranc_mic_%s_%s[i] for i in range(len(n_scat_tranc_mic_%s_%s))]"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux,isot_py[isot],mix_aux))
   exec("n_scat_isot_mac_%s_%s=[float(atom_dens[isot])*n_scat_isot_mic_%s_%s[i] for i in range(len(n_scat_isot_mic_%s_%s))]"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux,isot_py[isot],mix_aux))
   exec("n_tot_isot_mac_%s_%s=[float(atom_dens[isot])*n_tot_isot_mic_%s_%s[i] for i in range(len(n_tot_isot_mic_%s_%s))]"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux,isot_py[isot],mix_aux))
   exec("n_tot_tranc_mac_%s_%s=[float(atom_dens[isot])*n_tot_tranc_mic_%s_%s[i] for i in range(len(n_tot_tranc_mic_%s_%s))]"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux,isot_py[isot],mix_aux))
   exec("n_nufis_mac_%s_%s=[float(atom_dens[isot])*vec_%s_NUSIF_%s[i] for i in range(len(vec_%s_NUSIF_%s))]"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux,isot_py[isot],mix_aux))
   exec("n_fis_mac_%s_%s=[float(atom_dens[isot])*vec_%s_NFTOT_%s[i] for i in range(len(vec_%s_NFTOT_%s))]"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux,isot_py[isot],mix_aux))
   exec("sum_nufis_mac_%s_%s=0"%(isot_py[isot],mix_aux))   
   for g_aux in range(GROUPS):
    exec("sum_nufis_mac_%s_%s=sum_nufis_mac_%s_%s+n_nufis_mac_%s_%s[g_aux]"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux,isot_py[isot],mix_aux))
   exec("chi_mac_aux_%s_%s=[(vec_%s_CHI_X_%s[i])*sum_nufis_mac_%s_%s for i in range(len(vec_%s_CHI_X_%s))]"%(isot_py[isot],mix_aux,isot_py[isot],mix_aux,isot_py[isot],mix_aux,isot_py[isot],mix_aux))    
   
  # END OF REACTIONS WHILE
    
 isot=isot+1
# END OF MAIN WHILE (ISOTOPE)######################################################################################################################
 
print "Now computing macroscopic XS for the different mixtures"
for mix in range(len(mixtures)):

 exec("n_tot_tranc_mac_%s=[0]*GROUPS"%(mixtures[mix]))
 exec("n_tot_isot_mac_%s=[0]*GROUPS"%(mixtures[mix]))
 exec("n_abs_mac_%s=[0]*GROUPS"%(mixtures[mix]))
 exec("n_scat_isot_mac_%s=[0]*GROUPS"%(mixtures[mix]))
 exec("n_scat_tranc_mac_%s=[0]*GROUPS"%(mixtures[mix]))
 exec("n_fis_mac_%s=[0]*GROUPS"%(mixtures[mix]))
 exec("n_nufis_mac_%s=[0]*GROUPS"%(mixtures[mix]))

 for g in range(GROUPS):
 
  exec("col_%s_mac_SCAT_ISOT_MTX_%s=[0]*GROUPS"%(g,mixtures[mix]))
  exec("col_%s_mac_SCAT_TRANC_MTX_%s=[0]*GROUPS"%(g,mixtures[mix]))
  exec("col_%s_mac_SCAT_P1_MTX_%s=[0]*GROUPS"%(g,mixtures[mix]))


  for isot in range(len(isotopes)):

   try:
    exec("n_tot_tranc_mac_%s_%s"%(isot_py[isot],mix_drag[mix]))
   except NameError:
    exec("n_tot_tranc_mac_%s_%s=[0]*GROUPS"%(isot_py[isot],mix_drag[mix]))

   try:
    exec("n_tot_isot_mac_%s_%s"%(isot_py[isot],mix_drag[mix]))
   except NameError:
    exec("n_tot_isot_mac_%s_%s=[0]*GROUPS"%(isot_py[isot],mix_drag[mix]))

   try:
    exec("n_abs_mac_%s_%s"%(isot_py[isot],mix_drag[mix]))
   except NameError:
    exec("n_abs_mac_%s_%s=[0]*GROUPS"%(isot_py[isot],mix_drag[mix]))

   try:
    exec("n_scat_isot_mac_%s_%s"%(isot_py[isot],mix_drag[mix]))
   except NameError:
    exec("n_scat_isot_mac_%s_%s=[0]*GROUPS"%(isot_py[isot],mix_drag[mix]))

   try:
    exec("n_scat_tranc_mac_%s_%s"%(isot_py[isot],mix_drag[mix]))
   except NameError:
    exec("n_scat_tranc_mac_%s_%s=[0]*GROUPS"%(isot_py[isot],mix_drag[mix]))

   try:
    exec("n_fis_mac_%s_%s"%(isot_py[isot],mix_drag[mix]))
   except NameError:
    exec("n_fis_mac_%s_%s=[0]*GROUPS"%(isot_py[isot],mix_drag[mix]))

   try:
    exec("n_nufis_mac_%s_%s"%(isot_py[isot],mix_drag[mix]))
   except NameError:
    exec("n_nufis_mac_%s_%s=[0]*GROUPS"%(isot_py[isot],mix_drag[mix]))
   
   try:
    exec("col_%s_%s_mac_SCAT_TRANC_MTX_%s"%(g,isot_py[isot],mix_drag[mix]))
   except NameError:
    exec("col_%s_%s_mac_SCAT_TRANC_MTX_%s=[0]*GROUPS"%(g,isot_py[isot],mix_drag[mix]))

   try:
    exec("col_%s_%s_mac_SCAT_ISOT_MTX_%s"%(g,isot_py[isot],mix_drag[mix]))
   except NameError:
    exec("col_%s_%s_mac_SCAT_ISOT_MTX_%s=[0]*GROUPS"%(g,isot_py[isot],mix_drag[mix]))
    
   try:
    exec("col_%s_%s_mac_SCAT_P1_MTX_%s"%(g,isot_py[isot],mix_drag[mix]))
   except NameError:
    exec("col_%s_%s_mac_SCAT_P1_MTX_%s=[0]*GROUPS"%(g,isot_py[isot],mix_drag[mix]))

   
   for g_aux in range(GROUPS):

    exec("col_%s_mac_SCAT_TRANC_MTX_%s[g_aux]=col_%s_mac_SCAT_TRANC_MTX_%s[g_aux]+col_%s_%s_mac_SCAT_TRANC_MTX_%s[g_aux]"%(g,mixtures[mix],g,mixtures[mix],g,isot_py[isot],mix_drag[mix]))

    exec("col_%s_mac_SCAT_ISOT_MTX_%s[g_aux]=col_%s_mac_SCAT_ISOT_MTX_%s[g_aux]+col_%s_%s_mac_SCAT_ISOT_MTX_%s[g_aux]"%(g,mixtures[mix],g,mixtures[mix],g,isot_py[isot],mix_drag[mix]))

    exec("col_%s_mac_SCAT_P1_MTX_%s[g_aux]=col_%s_mac_SCAT_P1_MTX_%s[g_aux]+col_%s_%s_mac_SCAT_P1_MTX_%s[g_aux]"%(g,mixtures[mix],g,mixtures[mix],g,isot_py[isot],mix_drag[mix]))

   exec("n_tot_tranc_mac_%s[g]=n_tot_tranc_mac_%s[g]+n_tot_tranc_mac_%s_%s[g]"%(mixtures[mix],mixtures[mix],isot_py[isot],mix_drag[mix]))
   exec("n_tot_isot_mac_%s[g]=n_tot_isot_mac_%s[g]+n_tot_isot_mac_%s_%s[g]"%(mixtures[mix],mixtures[mix],isot_py[isot],mix_drag[mix]))
   exec("n_abs_mac_%s[g]=n_abs_mac_%s[g]+n_abs_mac_%s_%s[g]"%(mixtures[mix],mixtures[mix],isot_py[isot],mix_drag[mix]))
   exec("n_scat_isot_mac_%s[g]=n_scat_isot_mac_%s[g]+n_scat_isot_mac_%s_%s[g]"%(mixtures[mix],mixtures[mix],isot_py[isot],mix_drag[mix]))
   exec("n_scat_tranc_mac_%s[g]=n_scat_tranc_mac_%s[g]+n_scat_tranc_mac_%s_%s[g]"%(mixtures[mix],mixtures[mix],isot_py[isot],mix_drag[mix]))
   exec("n_fis_mac_%s[g]=n_fis_mac_%s[g]+n_fis_mac_%s_%s[g]"%(mixtures[mix],mixtures[mix],isot_py[isot],mix_drag[mix]))
   exec("n_nufis_mac_%s[g]=n_nufis_mac_%s[g]+n_nufis_mac_%s_%s[g]"%(mixtures[mix],mixtures[mix],isot_py[isot],mix_drag[mix]))
  #
 #
#

####### EVALUATING FISSION SPECTRA (CHI) ##########################################################################################
# THE SPECTRA IS WEIGHTED AMONG THE DIFFERENT FISSIONABLE ISOTOPES CONTAINED IN THE FUEL ##########################################

for mix in range(len(mixtures)):
 if eval("n_nufis_mac_%s[0]"%(mixtures[mix]))==0:
  exec("chi_final_%s=[0]*GROUPS"%mixtures[mix])
   
 else:
  exec("chi_final_%s=[0]*GROUPS"%mixtures[mix])
  
     
  for g in range(GROUPS):
   chi_aux_den=0
   for fiss in range(len(ss_isot_py)):
    exec("chi_final_%s[g]=chi_final_%s[g]+chi_mac_aux_%s_%s[g]"%(mixtures[mix],mixtures[mix],ss_isot_py[fiss],mix_drag[mix]))
    exec("chi_aux_den=chi_aux_den+sum_nufis_mac_%s_%s"%(ss_isot_py[fiss],mix_drag[mix]))

   exec("chi_final_%s[g]=chi_final_%s[g]/chi_aux_den"%(mixtures[mix],mixtures[mix]))
  #
 #
# ##################################################################################################################################

exec("m=open('%s','w')"%files[1])
exec("print 'Now printing the file for OpenMOC materials %s (transport corrected)'%files[1]")
m.write('dataset = {}\n')

m.write("dataset['Energy Groups'] = %s\n"%GROUPS)
m.write("dataset['Materials'] = {}\n")

m.write("test_dataset = dataset['Materials']\n\n")

for mix in range(len(mixtures)):
 
 m.write('###############################################################################\n')
 m.write('################################      %s      ################################\n'%mixtures[mix])
 m.write('###############################################################################\n\n')

 m.write('# Create a subdictionary for %s materials data\n'%mixtures[mix])
 m.write("test_dataset['%s'] = {}\n\n"%mixtures[mix])

 m.write("test_dataset['%s']['Total XS'] =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f]\n\n"%(eval("(n_tot_tranc_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_tot_tranc_mac_%s[g])"%mixtures[mix])))

 m.write("test_dataset['%s']['Absorption XS'] =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f]\n\n"%(eval("(n_abs_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_abs_mac_%s[g])"%mixtures[mix])))  

 m.write("test_dataset['%s']['Fission XS'] =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f]\n\n"%(eval("(n_fis_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_fis_mac_%s[g])"%mixtures[mix])))

 m.write("test_dataset['%s']['Nu Fission XS'] =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f]\n\n"%(eval("(n_nufis_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_nufis_mac_%s[g])"%mixtures[mix])))   

 m.write("test_dataset['%s']['Chi'] =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f]\n\n"%(eval("(chi_final_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(chi_final_%s[g])"%mixtures[mix]))) 

 m.write("test_dataset['%s']['Scattering XS'] =["%mixtures[mix])
 
 for g in range(GROUPS):
  for g_aux in range(GROUPS):
   if g==GROUPS-1 and g_aux==GROUPS-1:
    m.write("%.8f]\n "%(eval("(col_%s_mac_SCAT_TRANC_MTX_%s[%s])"%(g_aux,mixtures[mix],g))))
   else:
    m.write("%.8f, "%(eval("(col_%s_mac_SCAT_TRANC_MTX_%s[%s])"%(g_aux,mixtures[mix],g))))

m.close()

exec("m=open('%s','w')"%files[2])
exec("print 'Now printing the file for OpenMOC materials %s  (isotropic scattering)'%files[2]")
m.write('dataset = {}\n')

m.write("dataset['Energy Groups'] = %s\n"%GROUPS)
m.write("dataset['Materials'] = {}\n")

m.write("test_dataset = dataset['Materials']\n\n")

for mix in range(len(mixtures)):
 
 m.write('###############################################################################\n')
 m.write('################################      %s      ################################\n'%mixtures[mix])
 m.write('###############################################################################\n\n')

 m.write('# Create a subdictionary for %s materials data\n'%mixtures[mix])
 m.write("test_dataset['%s'] = {}\n\n"%mixtures[mix])

 m.write("test_dataset['%s']['Total XS'] =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f]\n\n"%(eval("(n_tot_isot_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_tot_isot_mac_%s[g])"%mixtures[mix])))

 m.write("test_dataset['%s']['Absorption XS'] =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f]\n\n"%(eval("(n_abs_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_abs_mac_%s[g])"%mixtures[mix])))  

 m.write("test_dataset['%s']['Fission XS'] =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f]\n\n"%(eval("(n_fis_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_fis_mac_%s[g])"%mixtures[mix])))

 m.write("test_dataset['%s']['Nu Fission XS'] =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f]\n\n"%(eval("(n_nufis_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_nufis_mac_%s[g])"%mixtures[mix])))   

 m.write("test_dataset['%s']['Chi'] =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f]\n\n"%(eval("(chi_final_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(chi_final_%s[g])"%mixtures[mix]))) 

 m.write("test_dataset['%s']['Scattering XS'] =["%mixtures[mix])
 
 for g in range(GROUPS):
  for g_aux in range(GROUPS):
   if g==GROUPS-1 and g_aux==GROUPS-1:
    m.write("%.8f]\n "%(eval("(col_%s_mac_SCAT_ISOT_MTX_%s[%s])"%(g_aux,mixtures[mix],g))))
   else:
    m.write("%.8f, "%(eval("(col_%s_mac_SCAT_ISOT_MTX_%s[%s])"%(g_aux,mixtures[mix],g))))


m.close()

exec("m=open('%s','w')"%files[3])
exec("print 'Now printing the file for Matlab/Octave processing %s  '%files[3]")
m.write("%This file contains the different macroscopic XS per mixture that have been processed from DRAGON\n")
m.write("%As previously warned in the python script, the transport correction is as follows: NTOT_TRANC = NTOT0 - SIGS01 and SCAT_MTX_TRANC = SCAT00-SCAT01\n")
m.write("%This means that each term of the P0 matrix has been substracted to its correspondent P1 matrix term \n")
m.write("%This type of transport correction might not be correct and may be disregarded\n")
m.write("%ONLY THE ISOTROPIC MACROSCOPIC CROSS-SECTIONS PER MIXTURE HAVE BEEN VALIDATED\n")
m.write("%Nevertheless, since this file contains P0 and P1 matrices of the different mixtures, you can use them to build your own transport corrected XS\n")
m.write("%You can modify the end of this file in order to add more figures and/or process the XS\n\n")
m.write("%Augusto Hernandez-Solis, October 2014 @ KTH, Sweden\n\n")
m.write('clear all\n\n')
m.write('clc \n\n')
m.write('close all \n\n')
m.write("disp('You can modify the end of the file %s in order to add more figures and/or process the XS')\n"%files[3])
m.write("disp('Type help %s for more info')\n\n"%files[3])

for mix in range(len(mixtures)):

 m.write("NTOT0_%s =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f];\n\n"%(eval("(n_tot_isot_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_tot_isot_mac_%s[g])"%mixtures[mix])))

 m.write("NTOT_TRANC_%s =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f];\n\n"%(eval("(n_tot_tranc_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_tot_tranc_mac_%s[g])"%mixtures[mix])))

 m.write("ABS_%s =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f];\n\n"%(eval("(n_abs_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_abs_mac_%s[g])"%mixtures[mix])))  

 m.write("NFISTOT_%s =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f];\n\n"%(eval("(n_fis_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_fis_mac_%s[g])"%mixtures[mix])))

 m.write("NUFIS_%s =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f];\n\n"%(eval("(n_nufis_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_nufis_mac_%s[g])"%mixtures[mix])))   

 m.write("CHI_%s =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f];\n\n"%(eval("(chi_final_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(chi_final_%s[g])"%mixtures[mix]))) 

 m.write("SCAT00_MTX_vec_%s =["%mixtures[mix])
 
 for g in range(GROUPS):
  for g_aux in range(GROUPS):
   if g==GROUPS-1 and g_aux==GROUPS-1:
    m.write("%.8f];\n "%(eval("(col_%s_mac_SCAT_ISOT_MTX_%s[%s])"%(g_aux,mixtures[mix],g))))
   else:
    m.write("%.8f, "%(eval("(col_%s_mac_SCAT_ISOT_MTX_%s[%s])"%(g_aux,mixtures[mix],g))))

 m.write("SCAT01_MTX_vec_%s =["%mixtures[mix])
 
 for g in range(GROUPS):
  for g_aux in range(GROUPS):
   if g==GROUPS-1 and g_aux==GROUPS-1:
    m.write("%.8f];\n "%(eval("(col_%s_mac_SCAT_P1_MTX_%s[%s])"%(g_aux,mixtures[mix],g))))
   else:
    m.write("%.8f, "%(eval("(col_%s_mac_SCAT_P1_MTX_%s[%s])"%(g_aux,mixtures[mix],g))))

 m.write("SIGS00_%s =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f];\n\n"%(eval("(n_scat_isot_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_scat_isot_mac_%s[g])"%mixtures[mix])))

 m.write("SIGS_TRANC_%s =["%mixtures[mix])
 for g in range(GROUPS):
  if g==GROUPS-1:
   m.write("%.8f];\n\n"%(eval("(n_scat_tranc_mac_%s[g])"%mixtures[mix])))
  else:
   m.write("%.8f, "%(eval("(n_scat_tranc_mac_%s[g])"%mixtures[mix])))

 m.write("SIGS01_%s=-1*(SIGS_TRANC_%s-SIGS00_%s);\n\n"%(mixtures[mix],mixtures[mix],mixtures[mix]))

 m.write("for i=1:%s\n\n"%GROUPS)

 m.write("    SCAT00_MTX_%s(i,:)=SCAT00_MTX_vec_%s(1+%s*(i-1):%s*(i));\n"%(mixtures[mix],mixtures[mix],GROUPS,GROUPS))
 m.write("    SCAT01_MTX_%s(i,:)=SCAT01_MTX_vec_%s(1+%s*(i-1):%s*(i));\n"%(mixtures[mix],mixtures[mix],GROUPS,GROUPS))
 
 m.write("end\n\n")
# 
m.write("grp_172=[1.96403E+07 1.73325E+07 1.49182E+07 1.38403E+07 1.16183E+07 1.00000E+07 8.18731E+06 6.70320E+06 6.06531E+06 5.48812E+06 ...\n")
m.write("4.49329E+06 3.67879E+06 3.01194E+06 2.46597E+06 2.23130E+06 2.01897E+06 1.65299E+06 1.35335E+06 1.22456E+06 1.10803E+06 ...\n")
m.write("1.00259E+06 9.07180E+05 8.20850E+05 6.08101E+05 5.50232E+05 4.97871E+05 4.50492E+05 4.07622E+05 3.01974E+05 2.73237E+05 ...\n")
m.write("2.47235E+05 1.83156E+05 1.22773E+05 1.11090E+05 8.22975E+04 6.73795E+04 5.51656E+04 4.08677E+04 3.69786E+04 2.92830E+04 ...\n")
m.write("2.73944E+04 2.47875E+04 1.66156E+04 1.50344E+04 1.11378E+04 9.11882E+03 7.46586E+03 5.53085E+03 5.00450E+03 3.52662E+03 ...\n")
m.write("3.35463E+03 2.24867E+03 2.03468E+03 1.50733E+03 1.43382E+03 1.23410E+03 1.01039E+03 9.14242E+02 7.48518E+02 6.77287E+02 ...\n")
m.write("4.53999E+02 3.71703E+02 3.04325E+02 2.03995E+02 1.48625E+02 1.36742E+02 9.16609E+01 7.56736E+01 6.79040E+01 5.55951E+01 ...\n")
m.write("5.15780E+01 4.82516E+01 4.55174E+01 4.01690E+01 3.72665E+01 3.37201E+01 3.05113E+01 2.76077E+01 2.49805E+01 2.26033E+01 ...\n")
m.write("1.94548E+01 1.59283E+01 1.37096E+01 1.12245E+01 9.90555E+00 9.18981E+00 8.31529E+00 7.52398E+00 6.16012E+00 5.34643E+00 ...\n")
m.write("5.04348E+00 4.12925E+00 4.00000E+00 3.38075E+00 3.30000E+00 2.76792E+00 2.72000E+00 2.60000E+00 2.55000E+00 2.36000E+00 ...\n")
m.write("2.13000E+00 2.10000E+00 2.02000E+00 1.93000E+00 1.84000E+00 1.75500E+00 1.67000E+00 1.59000E+00 1.50000E+00 1.47500E+00 ...\n")
m.write("1.44498E+00 1.37000E+00 1.33750E+00 1.30000E+00 1.23500E+00 1.17000E+00 1.15000E+00 1.12535E+00 1.11000E+00 1.09700E+00 ...\n")
m.write("1.07100E+00 1.04500E+00 1.03500E+00 1.02000E+00 9.96000E-01 9.86000E-01 9.72000E-01 9.50000E-01 9.30000E-01 9.10000E-01 ...\n")
m.write("8.60000E-01 8.50000E-01 7.90000E-01 7.80000E-01 7.05000E-01 6.25000E-01 5.40000E-01 5.00000E-01 4.85000E-01 4.33000E-01 ...\n")
m.write("4.00000E-01 3.91000E-01 3.50000E-01 3.20000E-01 3.14500E-01 3.00000E-01 2.80000E-01 2.48000E-01 2.20000E-01 1.89000E-01 ...\n")
m.write("1.80000E-01 1.60000E-01 1.40000E-01 1.34000E-01 1.15000E-01 1.00000E-01 9.50000E-02 8.00000E-02 7.70000E-02 6.70000E-02 ...\n")
m.write("5.80000E-02 5.00000E-02 4.20000E-02 3.50000E-02 3.00000E-02 2.50000E-02 2.00000E-02 1.50000E-02 1.00000E-02 6.90000E-03 ...\n")
m.write("5.00000E-03 3.00000E-03 1.00000E-05];\n\n")
 
m.write("grp_69=[1.00000E+07 6.06550E+06 3.67900E+06 2.23100E+06 1.35300E+06 8.21000E+05 5.00000E+05 3.02500E+05 1.83000E+05 ...\n")
m.write("1.11000E+05 6.73400E+04 4.08500E+04 2.47800E+04 1.50300E+04 9.11800E+03 5.53000E+03 3.51910E+03 2.23945E+03 ...\n")
m.write("1.42510E+03 9.06899E+02 3.67263E+02 1.48729E+02 7.55014E+01 4.80520E+01 2.77000E+01 1.59680E+01 9.87700E+00 ...\n")
m.write("4.00000E+00 3.30000E+00 2.60000E+00 2.10000E+00 1.50000E+00 1.30000E+00 1.15000E+00 1.12300E+00 1.09700E+00 ...\n")
m.write("1.07100E+00 1.04500E+00 1.02000E+00 9.96000E-01 9.72000E-01 9.50000E-01 9.10000E-01 8.50000E-01 7.80000E-01 ...\n")
m.write("6.25000E-01 5.00000E-01 4.00000E-01 3.50000E-01 3.20000E-01 3.00000E-01 2.80000E-01 2.50000E-01 2.20000E-01 ...\n")
m.write("1.80000E-01 1.40000E-01 1.00000E-01 8.00000E-02 6.70000E-02 5.80000E-02 5.00000E-02 4.20000E-02 3.50000E-02 ...\n")
m.write("3.00000E-02 2.50000E-02 2.00000E-02 1.50000E-02 1.00000E-02 5.00000E-03 1.00000E-05];\n\n")

m.write("figure(1)\n")
m.write("loglog(grp_%s(1:%s),NFISTOT_%s,'LineWidth',3)\n"%(GROUPS,GROUPS,mixtures[mix]))
m.write("title('NFISTOT Fuel XS vs. Energy')\n")
m.write("xlabel('Energy (eV)')\n")
m.write("ylabel('NF (1/cm)')\n")
 
m.close()



